export const environment = {
  // firebase: {
  //   projectId: 'vault-f5c42',
  //   appId: '1:194199338743:web:c2490eabfe58d42ce89df2',
  //   storageBucket: 'vault-f5c42.appspot.com',
  //   apiKey: 'AIzaSyCGp6wHTbhh-rlSeR1x2_CbUDAWQs4hQHA',
  //   authDomain: 'vault-f5c42.firebaseapp.com',
  //   messagingSenderId: '194199338743',
  // },
  firebase : {
    apiKey: "AIzaSyAZFrMNNMGfoRYwImlLu_XmMelwpS6C3h8",
    authDomain: "valut-svc.firebaseapp.com",
    projectId: "valut-svc",
    storageBucket: "valut-svc.appspot.com",
    messagingSenderId: "215157672172",
    appId: "1:215157672172:web:d31acff49a9ba1ad7abdc9",
    measurementId: "G-9Y53GC4VZG"
  },
};